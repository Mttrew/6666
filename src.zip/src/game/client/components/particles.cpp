/* (c) Magnus Auvinen. See licence.txt in the root of the distribution for more information. */
/* If you are missing that file, acquire a complete release at teeworlds.com.                */
#include "particles.h"

#include <base/dbg.h>
#include <base/math.h>
#include <algorithm>
#include <cmath>
#include <base/time.h>

#include <engine/demo.h>
#include <engine/shared/config.h>
#include <engine/graphics.h>

#include <generated/client_data.h>

#include <game/client/gameclient.h>

CParticles::CParticles()
{
	CParticles::OnReset();
	m_RenderTrail.m_pParts = this;
	m_RenderTrailExtra.m_pParts = this;
	m_RenderExplosions.m_pParts = this;
	m_RenderExtra.m_pParts = this;
	m_RenderGeneral.m_pParts = this;
}

void CParticles::OnReset()
{
	// reset particles
	for(int i = 0; i < MAX_PARTICLES; i++)
	{
		m_aParticles[i].m_PrevPart = i - 1;
		m_aParticles[i].m_NextPart = i + 1;
	}

	m_aParticles[0].m_PrevPart = 0;
	m_aParticles[MAX_PARTICLES - 1].m_NextPart = -1;
	m_FirstFree = 0;

	std::fill(std::begin(m_aFirstPart), std::end(m_aFirstPart), -1);
	for(CAtmosphereParticle &Particle : m_aAtmosphereParticles)
		Particle = CAtmosphereParticle{};
	m_AtmosphereSpawnTimer = 0.0f;
}

void CParticles::Add(int Group, CParticle *pPart, float TimePassed)
{
	if(GameClient()->IsWorldPaused() || GameClient()->IsDemoPlaybackPaused())
	{
		return;
	}

	if(m_FirstFree == -1)
		return;

	// remove from the free list
	int Id = m_FirstFree;
	m_FirstFree = m_aParticles[Id].m_NextPart;
	if(m_FirstFree != -1)
		m_aParticles[m_FirstFree].m_PrevPart = -1;

	// copy data
	m_aParticles[Id] = *pPart;

	// insert to the group list
	m_aParticles[Id].m_PrevPart = -1;
	m_aParticles[Id].m_NextPart = m_aFirstPart[Group];
	if(m_aFirstPart[Group] != -1)
		m_aParticles[m_aFirstPart[Group]].m_PrevPart = Id;
	m_aFirstPart[Group] = Id;

	// set some parameters
	m_aParticles[Id].m_Life = TimePassed;
}

void CParticles::Update(float TimePassed)
{
	if(TimePassed <= 0.0f)
		return;

	m_FrictionFraction += TimePassed;

	if(m_FrictionFraction > 2.0f) // safety measure
		m_FrictionFraction = 0;

	int FrictionCount = 0;
	while(m_FrictionFraction > 0.05f)
	{
		FrictionCount++;
		m_FrictionFraction -= 0.05f;
	}

	for(int &FirstPart : m_aFirstPart)
	{
		int i = FirstPart;
		while(i != -1)
		{
			int Next = m_aParticles[i].m_NextPart;
			m_aParticles[i].m_Vel.y += m_aParticles[i].m_Gravity * TimePassed;

			for(int f = 0; f < FrictionCount; f++) // apply friction
				m_aParticles[i].m_Vel *= m_aParticles[i].m_Friction;

			// move the point
			vec2 Vel = m_aParticles[i].m_Vel * TimePassed;
			if(m_aParticles[i].m_Collides)
			{
				Collision()->MovePoint(&m_aParticles[i].m_Pos, &Vel, random_float(0.1f, 1.0f), nullptr);
			}
			else
			{
				m_aParticles[i].m_Pos += Vel;
			}
			m_aParticles[i].m_Vel = Vel * (1.0f / TimePassed);

			m_aParticles[i].m_Life += TimePassed;
			m_aParticles[i].m_Rot += TimePassed * m_aParticles[i].m_Rotspeed;

			// check particle death
			if(m_aParticles[i].m_Life > m_aParticles[i].m_LifeSpan)
			{
				// remove it from the group list
				if(m_aParticles[i].m_PrevPart != -1)
					m_aParticles[m_aParticles[i].m_PrevPart].m_NextPart = m_aParticles[i].m_NextPart;
				else
					FirstPart = m_aParticles[i].m_NextPart;

				if(m_aParticles[i].m_NextPart != -1)
					m_aParticles[m_aParticles[i].m_NextPart].m_PrevPart = m_aParticles[i].m_PrevPart;

				// insert to the free list
				if(m_FirstFree != -1)
					m_aParticles[m_FirstFree].m_PrevPart = i;
				m_aParticles[i].m_PrevPart = -1;
				m_aParticles[i].m_NextPart = m_FirstFree;
				m_FirstFree = i;
			}

			i = Next;
		}
	}
}

void CParticles::OnRender()
{
	if(Client()->State() != IClient::STATE_ONLINE && Client()->State() != IClient::STATE_DEMOPLAYBACK)
		return;

	set_new_tick();
	const int64_t Now = time();
	const float TimePassed = (float)((Now - m_LastRenderTime) / (double)time_freq()) * GameClient()->GetAnimationPlaybackSpeed();
	Update(TimePassed);
	UpdateAtmosphere(std::clamp(TimePassed, 0.0f, 0.1f));
	m_LastRenderTime = Now;
}

void CParticles::UpdateAtmosphere(float TimePassed)
{
	const bool SnowEnabled = g_Config.m_XxAtmosphereSnow != 0;
	const bool AshEnabled = g_Config.m_XxAtmosphereAsh != 0;
	if((!SnowEnabled && !AshEnabled) || TimePassed <= 0.0f)
	{
		if(!SnowEnabled && !AshEnabled)
		{
			for(CAtmosphereParticle &Particle : m_aAtmosphereParticles)
				Particle.m_Active = false;
		}
		return;
	}

	const CScreenRect Screen = Graphics()->GetScreen();
	const float Speed = g_Config.m_XxAtmosphereSpeed / 100.0f;
	const int MaxActive = std::clamp(20 + g_Config.m_XxAtmosphereDensity, 20, MAX_ATMOSPHERE_PARTICLES);
	int ActiveCount = 0;
	for(const CAtmosphereParticle &Particle : m_aAtmosphereParticles)
		ActiveCount += Particle.m_Active;

	m_AtmosphereSpawnTimer -= TimePassed;
	const float SpawnInterval = 8.0f / std::max(1, g_Config.m_XxAtmosphereDensity);
	while(m_AtmosphereSpawnTimer <= 0.0f && ActiveCount < MaxActive)
	{
		CAtmosphereParticle *pFree = nullptr;
		for(CAtmosphereParticle &Particle : m_aAtmosphereParticles)
		{
			if(!Particle.m_Active)
			{
				pFree = &Particle;
				break;
			}
		}
		if(pFree == nullptr)
			break;

		const bool Snow = SnowEnabled && (!AshEnabled || random_float(0.0f, 1.0f) < 0.68f);
		pFree->m_Active = true;
		pFree->m_Snow = Snow;
		pFree->m_Settled = false;
		pFree->m_Pos = vec2(
			random_float(Screen.m_TopLeft.x - 24.0f, Screen.m_BottomRight.x + 24.0f),
			Screen.m_TopLeft.y - random_float(8.0f, 90.0f));
		pFree->m_Vel = vec2(random_float(-10.0f, 10.0f), random_float(Snow ? 8.0f : 5.0f, Snow ? 20.0f : 13.0f) * Speed);
		pFree->m_Life = 0.0f;
		pFree->m_LifeSpan = random_float(18.0f, 32.0f);
		pFree->m_Size = Snow ? random_float(2.2f, 4.2f) : random_float(1.1f, 2.3f);
		pFree->m_Phase = random_float(0.0f, 6.2831853f);
		pFree->m_Rotation = random_float(0.0f, 6.2831853f);
		pFree->m_RotationSpeed = random_float(-1.8f, 1.8f);
		pFree->m_Wind = random_float(-13.0f, 13.0f);
		++ActiveCount;
		m_AtmosphereSpawnTimer += SpawnInterval;
	}
	if(ActiveCount >= MaxActive && m_AtmosphereSpawnTimer < 0.0f)
		m_AtmosphereSpawnTimer = 0.0f;
	if(m_AtmosphereSpawnTimer < -1.0f)
		m_AtmosphereSpawnTimer = 0.0f;

	// A flake has a tiny visual footprint. Check several points around it so
	// it lands on the actual collision surface instead of snapping to a tile grid.
	const auto IsBlocked = [this](const vec2 &Pos, float Radius) {
		return Collision()->CheckPoint(Pos.x, Pos.y) ||
			Collision()->CheckPoint(Pos.x - Radius, Pos.y) ||
			Collision()->CheckPoint(Pos.x + Radius, Pos.y) ||
			Collision()->CheckPoint(Pos.x, Pos.y - Radius) ||
			Collision()->CheckPoint(Pos.x, Pos.y + Radius);
	};

	for(CAtmosphereParticle &Particle : m_aAtmosphereParticles)
	{
		if(!Particle.m_Active)
			continue;

		Particle.m_Life += TimePassed;
		Particle.m_Phase += TimePassed * (Particle.m_Snow ? 1.25f : 0.75f);
		Particle.m_Rotation += TimePassed * Particle.m_RotationSpeed;

		// Tee interaction is cosmetic only: the particle is pushed away from
		// the rendered character position; character physics is never touched.
		for(int ClientId = 0; ClientId < MAX_CLIENTS; ++ClientId)
		{
			const auto &Character = GameClient()->m_Snap.m_aCharacters[ClientId];
			if(!Character.m_Active)
				continue;
			const vec2 Delta = Particle.m_Pos - GameClient()->m_aClients[ClientId].m_RenderPos;
			const float Distance = length(Delta);
			const float Radius = Particle.m_Snow ? 39.0f : 31.0f;
			if(Distance >= Radius)
				continue;

			const vec2 Direction = Distance > 0.01f ? Delta / Distance : vec2(0.0f, -1.0f);
			const float Push = Radius - Distance;
			Particle.m_Pos += Direction * (Push * std::min(1.0f, TimePassed * 12.0f));
			Particle.m_Vel += Direction * (Particle.m_Snow ? 105.0f : 70.0f) * TimePassed;
			Particle.m_Settled = false;
		}

		if(!Particle.m_Settled)
		{
			const float Flutter = Particle.m_Snow ? 10.0f : 5.0f;
			const float WindTarget = Particle.m_Wind + std::sin(Particle.m_Phase * 1.7f) * Flutter + std::sin(Particle.m_Phase * 0.43f) * 5.0f;
			Particle.m_Vel.x += (WindTarget - Particle.m_Vel.x) * std::min(1.0f, TimePassed * (Particle.m_Snow ? 1.5f : 0.8f));
			Particle.m_Vel.y += (Particle.m_Snow ? 17.0f : 8.0f) * Speed * TimePassed;
			Particle.m_Vel.y = std::min(Particle.m_Vel.y, (Particle.m_Snow ? 48.0f : 27.0f) * Speed);

			// Substeps prevent flakes tunnelling through thin collision edges at low FPS.
			const vec2 TotalMove = Particle.m_Vel * TimePassed;
			const int Steps = std::clamp((int)std::ceil(length(TotalMove) / 3.0f), 1, 12);
			const vec2 StepMove = TotalMove / Steps;
			const float Radius = std::max(0.8f, Particle.m_Size * 0.45f);
			for(int Step = 0; Step < Steps && !Particle.m_Settled; ++Step)
			{
				const vec2 XPos(Particle.m_Pos.x + StepMove.x, Particle.m_Pos.y);
				if(!IsBlocked(XPos, Radius))
					Particle.m_Pos.x = XPos.x;
				else
					Particle.m_Vel.x *= -0.12f;

				const vec2 YPos(Particle.m_Pos.x, Particle.m_Pos.y + StepMove.y);
				if(!IsBlocked(YPos, Radius))
					Particle.m_Pos.y = YPos.y;
				else if(StepMove.y > 0.0f)
				{
					// Find the last free position against the real tile surface.
					float FreeDistance = 0.0f;
					float BlockedDistance = StepMove.y;
					for(int Iteration = 0; Iteration < 7; ++Iteration)
					{
						const float Mid = (FreeDistance + BlockedDistance) * 0.5f;
						if(IsBlocked(vec2(Particle.m_Pos.x, Particle.m_Pos.y + Mid), Radius))
							BlockedDistance = Mid;
						else
							FreeDistance = Mid;
					}
					Particle.m_Pos.y += FreeDistance;
					Particle.m_Vel = vec2(Particle.m_Vel.x * 0.22f, 0.0f);
					Particle.m_Settled = true;
					Particle.m_LifeSpan = Particle.m_Life + random_float(3.5f, 7.0f);
				}
				else
					Particle.m_Vel.y = 0.0f;
			}
		}

		if(Particle.m_Life > Particle.m_LifeSpan ||
			Particle.m_Pos.x < Screen.m_TopLeft.x - 96.0f ||
			Particle.m_Pos.x > Screen.m_BottomRight.x + 96.0f ||
			Particle.m_Pos.y > Screen.m_BottomRight.y + 96.0f)
			Particle.m_Active = false;
	}
}

void CParticles::RenderAtmosphere()
{
	const CScreenRect Screen = Graphics()->GetScreen();
	Graphics()->TextureClear();
	IGraphics::CLineItem aSnowLines[MAX_ATMOSPHERE_PARTICLES * 15];
	int NumSnowLines = 0;

	Graphics()->LinesBegin();
	Graphics()->SetColor(0.91f, 0.96f, 1.0f, 0.82f);
	for(const CAtmosphereParticle &Particle : m_aAtmosphereParticles)
	{
		if(!Particle.m_Active || !Particle.m_Snow || !Screen.Inside(Particle.m_Pos))
			continue;
		const float Fade = std::clamp((Particle.m_LifeSpan - Particle.m_Life) / 1.8f, 0.0f, 1.0f);
		const float Size = Particle.m_Size * Fade;
		if(Size < 0.25f)
			continue;

		// Three crystal arms plus small forked branches make flakes read as
		// snow crystals rather than plus signs. Rotation follows the airflow.
		for(int Arm = 0; Arm < 3; ++Arm)
		{
			const float Angle = Particle.m_Rotation + Arm * 1.04719755f;
			const vec2 Dir(std::cos(Angle), std::sin(Angle));
			const vec2 Side(-Dir.y, Dir.x);
			aSnowLines[NumSnowLines++] = IGraphics::CLineItem(
				Particle.m_Pos.x - Dir.x * Size, Particle.m_Pos.y - Dir.y * Size,
				Particle.m_Pos.x + Dir.x * Size, Particle.m_Pos.y + Dir.y * Size);
			for(int End = -1; End <= 1; End += 2)
			{
				const vec2 BranchPoint = Particle.m_Pos + Dir * (Size * 0.55f * End);
				const vec2 BranchBase = BranchPoint - Dir * (Size * 0.20f * End);
				const vec2 Branch = Side * (Size * 0.32f);
				aSnowLines[NumSnowLines++] = IGraphics::CLineItem(
					BranchPoint.x, BranchPoint.y,
					BranchBase.x + Branch.x, BranchBase.y + Branch.y);
				aSnowLines[NumSnowLines++] = IGraphics::CLineItem(
					BranchPoint.x, BranchPoint.y,
					BranchBase.x - Branch.x, BranchBase.y - Branch.y);
			}
		}
	}
	if(NumSnowLines > 0)
		Graphics()->LinesDraw(aSnowLines, NumSnowLines);
	Graphics()->LinesEnd();

	Graphics()->QuadsBegin();
	Graphics()->SetColor(0.48f, 0.45f, 0.42f, 0.58f);
	for(const CAtmosphereParticle &Particle : m_aAtmosphereParticles)
	{
		if(!Particle.m_Active || Particle.m_Snow || !Screen.Inside(Particle.m_Pos))
			continue;
		const float Fade = std::clamp((Particle.m_LifeSpan - Particle.m_Life) / 2.0f, 0.0f, 1.0f);
		const float Size = Particle.m_Size * Fade;
		if(Size < 0.2f)
			continue;
		Graphics()->DrawCircle(Particle.m_Pos.x, Particle.m_Pos.y, Size, 6);
	}
	Graphics()->QuadsEnd();
}

void CParticles::OnInit()
{
	Graphics()->QuadsSetRotation(0);
	Graphics()->SetColor(1.f, 1.f, 1.f, 1.f);

	m_ParticleQuadContainerIndex = Graphics()->CreateQuadContainer(false);

	for(int i = 0; i <= (SPRITE_PART9 - SPRITE_PART_SLICE); ++i)
	{
		Graphics()->QuadsSetSubset(0, 0, 1, 1);
		Graphics()->QuadContainerAddSprite(m_ParticleQuadContainerIndex, 1.f);
	}
	Graphics()->QuadContainerUpload(m_ParticleQuadContainerIndex);

	m_ExtraParticleQuadContainerIndex = Graphics()->CreateQuadContainer(false);

	for(int i = 0; i <= (SPRITE_PART_SPARKLE - SPRITE_PART_SNOWFLAKE); ++i)
	{
		Graphics()->QuadsSetSubset(0, 0, 1, 1);
		Graphics()->QuadContainerAddSprite(m_ExtraParticleQuadContainerIndex, 1.f);
	}

	Graphics()->QuadContainerUpload(m_ExtraParticleQuadContainerIndex);
}

bool CParticles::ParticleIsVisibleOnScreen(const vec2 &CurPos, float CurSize) const
{
	CScreenRect ScreenRect = Graphics()->GetScreen();

	// for simplicity assume the worst case rotation, that increases the bounding box around the particle by its diagonal
	const float SqrtOf2 = std::sqrt(2);
	CurSize = SqrtOf2 * CurSize;

	// always uses the mid of the particle
	float SizeHalf = CurSize / 2;
	ScreenRect.Expand(SizeHalf);

	return ScreenRect.Inside(CurPos);
}

void CParticles::RenderGroup(int Group)
{
	IGraphics::CTextureHandle *aParticles = GameClient()->m_ParticlesSkin.m_aSpriteParticles;
	int FirstParticleOffset = SPRITE_PART_SLICE;
	int ParticleQuadContainerIndex = m_ParticleQuadContainerIndex;
	if(Group == GROUP_EXTRA || Group == GROUP_TRAIL_EXTRA)
	{
		aParticles = GameClient()->m_ExtrasSkin.m_aSpriteParticles;
		FirstParticleOffset = SPRITE_PART_SNOWFLAKE;
		ParticleQuadContainerIndex = m_ExtraParticleQuadContainerIndex;
	}

	// don't use the buffer methods here, else the old renderer gets many draw calls
	if(Graphics()->IsQuadContainerBufferingEnabled())
	{
		int i = m_aFirstPart[Group];

		static IGraphics::SRenderSpriteInfo s_aParticleRenderInfo[MAX_PARTICLES];

		int CurParticleRenderCount = 0;

		// batching makes sense for stuff like ninja particles
		ColorRGBA LastColor;
		int LastQuadOffset = 0;

		if(i != -1)
		{
			float Alpha = m_aParticles[i].m_Color.a;
			if(m_aParticles[i].m_UseAlphaFading)
			{
				float a = m_aParticles[i].m_Life / m_aParticles[i].m_LifeSpan;
				Alpha = mix(m_aParticles[i].m_StartAlpha, m_aParticles[i].m_EndAlpha, a);
			}
			LastColor.r = m_aParticles[i].m_Color.r;
			LastColor.g = m_aParticles[i].m_Color.g;
			LastColor.b = m_aParticles[i].m_Color.b;
			LastColor.a = Alpha;

			Graphics()->SetColor(
				m_aParticles[i].m_Color.r,
				m_aParticles[i].m_Color.g,
				m_aParticles[i].m_Color.b,
				Alpha);

			LastQuadOffset = m_aParticles[i].m_Spr;
		}

		while(i != -1)
		{
			int QuadOffset = m_aParticles[i].m_Spr;
			float a = m_aParticles[i].m_Life / m_aParticles[i].m_LifeSpan;
			vec2 p = m_aParticles[i].m_Pos;
			float Size = mix(m_aParticles[i].m_StartSize, m_aParticles[i].m_EndSize, a);
			float Alpha = m_aParticles[i].m_Color.a;
			if(m_aParticles[i].m_UseAlphaFading)
			{
				Alpha = mix(m_aParticles[i].m_StartAlpha, m_aParticles[i].m_EndAlpha, a);
			}

			// the current position, respecting the size, is inside the viewport, render it, else ignore
			if(ParticleIsVisibleOnScreen(p, Size))
			{
				if((size_t)CurParticleRenderCount == GRAPHICS_MAX_PARTICLES_RENDER_COUNT || LastColor.r != m_aParticles[i].m_Color.r || LastColor.g != m_aParticles[i].m_Color.g || LastColor.b != m_aParticles[i].m_Color.b || LastColor.a != Alpha || LastQuadOffset != QuadOffset)
				{
					dbg_assert(LastQuadOffset >= FirstParticleOffset, "Invalid particle offsets: %d < %d", LastQuadOffset, FirstParticleOffset);
					Graphics()->TextureSet(aParticles[LastQuadOffset - FirstParticleOffset]);
					Graphics()->RenderQuadContainerAsSpriteMultiple(ParticleQuadContainerIndex, LastQuadOffset - FirstParticleOffset, CurParticleRenderCount, s_aParticleRenderInfo);
					CurParticleRenderCount = 0;
					LastQuadOffset = QuadOffset;

					Graphics()->SetColor(
						m_aParticles[i].m_Color.r,
						m_aParticles[i].m_Color.g,
						m_aParticles[i].m_Color.b,
						Alpha);

					LastColor.r = m_aParticles[i].m_Color.r;
					LastColor.g = m_aParticles[i].m_Color.g;
					LastColor.b = m_aParticles[i].m_Color.b;
					LastColor.a = Alpha;
				}

				s_aParticleRenderInfo[CurParticleRenderCount].m_Pos[0] = p.x;
				s_aParticleRenderInfo[CurParticleRenderCount].m_Pos[1] = p.y;
				s_aParticleRenderInfo[CurParticleRenderCount].m_Scale = Size;
				s_aParticleRenderInfo[CurParticleRenderCount].m_Rotation = m_aParticles[i].m_Rot;

				++CurParticleRenderCount;
			}

			i = m_aParticles[i].m_NextPart;
		}

		if(CurParticleRenderCount > 0)
		{
			dbg_assert(LastQuadOffset >= FirstParticleOffset, "Invalid particle offsets: %d < %d", LastQuadOffset, FirstParticleOffset);
			Graphics()->TextureSet(aParticles[LastQuadOffset - FirstParticleOffset]);
			Graphics()->RenderQuadContainerAsSpriteMultiple(ParticleQuadContainerIndex, LastQuadOffset - FirstParticleOffset, CurParticleRenderCount, s_aParticleRenderInfo);
		}
	}
	else
	{
		int i = m_aFirstPart[Group];

		Graphics()->WrapClamp();

		while(i != -1)
		{
			float a = m_aParticles[i].m_Life / m_aParticles[i].m_LifeSpan;
			vec2 p = m_aParticles[i].m_Pos;
			float Size = mix(m_aParticles[i].m_StartSize, m_aParticles[i].m_EndSize, a);
			float Alpha = m_aParticles[i].m_Color.a;
			if(m_aParticles[i].m_UseAlphaFading)
			{
				Alpha = mix(m_aParticles[i].m_StartAlpha, m_aParticles[i].m_EndAlpha, a);
			}

			// the current position, respecting the size, is inside the viewport, render it, else ignore
			if(ParticleIsVisibleOnScreen(p, Size))
			{
				Graphics()->TextureSet(aParticles[m_aParticles[i].m_Spr - FirstParticleOffset]);
				Graphics()->QuadsBegin();

				Graphics()->QuadsSetRotation(m_aParticles[i].m_Rot);

				Graphics()->SetColor(
					m_aParticles[i].m_Color.r,
					m_aParticles[i].m_Color.g,
					m_aParticles[i].m_Color.b,
					Alpha);

				IGraphics::CQuadItem QuadItem(p.x, p.y, Size, Size);
				Graphics()->QuadsDraw(&QuadItem, 1);
				Graphics()->QuadsEnd();
			}

			i = m_aParticles[i].m_NextPart;
		}
		Graphics()->WrapNormal();
	}

	if(Group == GROUP_GENERAL)
		RenderAtmosphere();
}
